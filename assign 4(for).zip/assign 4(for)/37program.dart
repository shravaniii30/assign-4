void main() {
  for (int x = 20; x <= 60; x++) {
    if (x % 7 == 0) {
      //x = x ^ 3;
      print(x*x*x);

    }
  }
}
