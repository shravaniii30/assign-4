void main() {
  for (int x = 31; x <= 55; x++) {
    print(x);
  }
}
