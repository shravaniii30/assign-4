void main() {
  for (int x = 63; x <= 123; x++) {
    if (x % 9 == 0) {
      print(x);
    }
  }
}
