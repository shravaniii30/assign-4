void main() {
  for (int x = 20; x <= 50; x++) {
    if (x % 4 != 0 && x % 4 == 3) {
      print(x);
    }
  }
}
