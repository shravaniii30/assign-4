void main() {
  
  
  for (int x = 100; x <= 120; x++) {
    if (x == x ^ 2) {
      print(x);
    }
  }
}
